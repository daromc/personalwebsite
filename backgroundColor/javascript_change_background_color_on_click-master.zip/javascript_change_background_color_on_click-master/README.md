# javascript_change_background_color_on_click
Javascript Project: How to change background color when a button is clicked! 

URL Link:
https://youtu.be/ho5hjedYWVM

Demo Website:
https://tbcodes.github.io/javascript_change_background_color_on_click/
